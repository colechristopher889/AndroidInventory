package com.chriscole.projectthree;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import java.util.ArrayList;
import java.util.List;

public class DetailsFragment extends Fragment {

    private static final List<ItemListener> listeners = new ArrayList<>();

    public interface ItemListener {
        void handleEdited(Item original, Item edited);
        void handleDeleted(Item deleted);
    }

    private Item mItem;

    public static DetailsFragment newInstance(int itemId) {
        DetailsFragment fragment = new DetailsFragment();
        Bundle args = new Bundle();
        args.putInt("itemId", itemId);
        fragment.setArguments(args);
        return fragment;
    }

    public static void register(ItemListener listener){
        listeners.add(listener);
    }

    public static void remove(ItemListener listener) {
        listeners.remove(listener);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        int itemId = 1;
        if (getArguments() != null) {
            itemId = getArguments().getInt("itemId");
        }

        mItem = ItemsDatabase.getInstance(getContext()).getItem(itemId);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_details, container, false);

        TextView nameTextView = (TextView) view.findViewById(R.id.lblItemName);
        nameTextView.setText(mItem.getName());

        TextView descriptionTextView = (TextView) view.findViewById(R.id.itemDescription);
        descriptionTextView.setText(mItem.getDescription());

        Button btnEdit = view.findViewById(R.id.btnEdit);

        btnEdit.setOnClickListener(l -> {

            AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
            builder.setTitle("Edit Item Details");

            View editView = inflater.inflate(R.layout.item_details, null);
            builder.setView(editView);

            EditText txtDescription = editView.findViewById(R.id.txtDescription);
            txtDescription.setText(mItem.getDescription());
            EditText txtName = editView.findViewById(R.id.txtName);
            txtName.setText(mItem.getName());

            builder.setPositiveButton("Ok", (dialogInterface, i) -> {
                String name = txtName.getText().toString();
                String description = txtDescription.getText().toString();
                Item edited = new Item(mItem.getId(), name, description);

                boolean isEdited = ItemsDatabase.getInstance(getContext()).editItem(mItem.getId(), edited);

                if (!isEdited){
                    Toast.makeText(getContext(), "Error editing item", Toast.LENGTH_SHORT).show();
                } else {
                    listeners.forEach(listener -> listener.handleEdited(mItem, edited));
                    mItem = edited;
                    nameTextView.setText(edited.getName());
                    descriptionTextView.setText(edited.getDescription());

                }
            });

            builder.setNegativeButton("Cancel", null);
            builder.create();

            builder.show();
        });

        Button btnDelete = view.findViewById(R.id.btnDelete);
        btnDelete.setOnClickListener(l -> {
            boolean isDeleted = ItemsDatabase.getInstance(getContext()).deleteItem(mItem.getId());

            if (!isDeleted){
                Toast.makeText(getContext(), "Error deleting item", Toast.LENGTH_SHORT).show();
            } else {
                listeners.forEach(listener -> listener.handleDeleted(mItem));
                getActivity().onBackPressed();
            }
        });

        return view;
    }
}
