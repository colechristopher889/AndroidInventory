package com.chriscole.projectthree;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

public class ListFragment extends Fragment implements DetailsFragment.ItemListener {

    private ItemAdapter adapter;

    @Override
    public void handleEdited(Item original, Item edited) {
        adapter.editItem(original, edited);
    }

    @Override
    public void handleDeleted(Item deleted) {
        adapter.deleteItem(deleted);
    }

    // For the activity to implement
    public interface OnItemSelectedListener {
        void onItemSelected(int itemId);
    }

    // Reference to the activity
    private OnItemSelectedListener mListener;

    public ListFragment(){
        DetailsFragment.register(this);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnItemSelectedListener) {
            mListener = (OnItemSelectedListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnItemSelectedListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_list, container, false);

        RecyclerView recyclerView = view.findViewById(R.id.item_recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        // Send items to recycler view
        adapter = new ItemAdapter();
        recyclerView.setAdapter(adapter);

        FloatingActionButton fab = view.findViewById(R.id.floating_action_button);

        fab.setOnClickListener(l -> {
            AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
            builder.setTitle("Add Item");

            View editView = inflater.inflate(R.layout.item_details, null);
            builder.setView(editView);

            EditText txtDescription = editView.findViewById(R.id.txtDescription);
            EditText txtName = editView.findViewById(R.id.txtName);

            builder.setPositiveButton("OK", (dialogInterface, i) -> {
                String name = txtName.getText().toString();
                String description = txtDescription.getText().toString();
                Item item = new Item(name, description);
                long result = ItemsDatabase.getInstance(getContext()).addItem(item);

                if (result == -1) {
                    Toast.makeText(getContext(), "Item name already exists", Toast.LENGTH_SHORT).show();
                } else {
                    adapter.addItem(new Item(result, item));
                }
            });

            builder.setNegativeButton("Cancel", null);
            builder.create();

            builder.show();
        });

        return view;
    }

    private class ItemHolder extends RecyclerView.ViewHolder
            implements View.OnClickListener {

        private Item mItem;

        private final TextView mNameTextView;

        public ItemHolder(LayoutInflater inflater, ViewGroup parent) {
            super(inflater.inflate(R.layout.list_item_item, parent, false));
            itemView.setOnClickListener(this);
            mNameTextView = itemView.findViewById(R.id.lblItemName);
        }

        public void bind(Item item) {
            mItem = item;
            mNameTextView.setText(mItem.getName());
        }

        @Override
        public void onClick(View view) {
            // Tell ListActivity what item was clicked
            mListener.onItemSelected((int)mItem.getId());
        }
    }

    private class ItemAdapter extends RecyclerView.Adapter<ItemHolder> {

        private final List<Item> mItems;

        public ItemAdapter() {
            mItems = ItemsDatabase.getInstance(getContext()).getItems();
        }

        @Override
        public ItemHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            LayoutInflater layoutInflater = LayoutInflater.from(getActivity());
            return new ItemHolder(layoutInflater, parent);
        }

        @Override
        public void onBindViewHolder(ItemHolder holder, int position) {
            Item item = mItems.get(position);
            holder.bind(item);
        }

        @Override
        public int getItemCount() {
            return mItems.size();
        }

        public void addItem(Item item){
            mItems.add(item);
            notifyItemInserted(mItems.size() - 1);
        }

        public void editItem(Item original, Item edited){
            int index = mItems.indexOf(original);

            mItems.add(index, edited);
            mItems.remove(original);
            notifyItemChanged(index);
        }

        public void deleteItem(Item item){
            int index = mItems.indexOf(item);
            mItems.remove(item);
            notifyItemRemoved(index);
        }
    }


}
