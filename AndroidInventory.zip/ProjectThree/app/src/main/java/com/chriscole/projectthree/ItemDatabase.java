package com.chriscole.projectthree;

import android.content.Context;
import android.content.res.Resources;
import java.util.ArrayList;
import java.util.List;

public class ItemDatabase {

    private static ItemDatabase instance;
    private final List<Item> items;

    private static int nextItemId;

    public static ItemDatabase getInstance(Context context) {
        if (instance == null) {
            instance = new ItemDatabase(context);
        }
        return instance;
    }

    private ItemDatabase(Context context) {
        items = new ArrayList<>();
        Resources res = context.getResources();
        String[] items = res.getStringArray(R.array.items);
        String[] descriptions = res.getStringArray(R.array.descriptions);
        for (int i = 0; i < items.length; i++) {
            this.items.add(new Item(i + 1, items[i], descriptions[i]));
        }

        nextItemId = items.length + 1;
    }

    public List<Item> getItems() {
        List<Item> copy = new ArrayList<>();
        for (Item b : items){
            copy.add(new Item(b));
        }
        return copy;
    }

    public Item getItem(int itemId) {
        for (Item item : items) {
            if (item.getId() == itemId) {
                return new Item(item);
            }
        }
        return null;
    }


    public int addItem(Item item){
        int itemId = -1;

        boolean itemExists = false;
        for (Item b : items){
            if (b.getName().equals(item.getName())){
                itemExists = true;
                break;
            }
        }

        if (!itemExists){
            itemId = nextItemId;
            Item newItem = new Item(itemId, item);
            items.add(newItem);
            nextItemId++;
        }

        return itemId;
    }


    public boolean editItem(int id, Item item){
        boolean isEdited = false;

        for (Item b : items){
            if (b.getId() == id){
                b.setName(item.getName());
                b.setDescription(item.getDescription());
                isEdited = true;
                break;
            }
        }

        return isEdited;
    }


    public boolean deleteItem(int id){
        boolean isDeleted = false;

        int index = -1;

        for (int i = 0; i < items.size(); i++){
            if (items.get(i).getId() == id){
                index = i;
                break;
            }
        }

        if (index != -1) {
            items.remove(index);
            isDeleted = true;
        }

        return isDeleted;
    }

}
